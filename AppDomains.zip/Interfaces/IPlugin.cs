﻿namespace AppDomains
{
    public interface IPlugin
    {
        bool ReadFile(string filePath);
        bool CreateFile(string filePath);
    }
}
