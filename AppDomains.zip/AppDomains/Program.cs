﻿using System;
using System.IO;
using System.Reflection;
using System.Security.Permissions;
using System.Security;

namespace AppDomains
{
    class Program
    {
        static void Main(string[] args)
        {
            const string thirdPartyClassPath = "ThirdPartyAssembly.UntrustedClass";
            const string thirdPartyAssemblyPath = "C:\\temp\\ThirdPartyAssembly.dll";
            var applicationBase = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

            Console.WriteLine("Creating App Pool And Permissions");
            var ps = new PermissionSet(PermissionState.None);
            ps.AddPermission(new SecurityPermission(SecurityPermissionFlag.Execution));
            ps.AddPermission(new FileIOPermission(PermissionState.None)
            {
                AllLocalFiles = FileIOPermissionAccess.Read
            });
            ps.AddPermission(new FileIOPermission(PermissionState.None)
            {
                AllLocalFiles = FileIOPermissionAccess.PathDiscovery
            });
               
            var domain = AppDomain.CreateDomain(
                                        "LowSecurityDomain",
                                        null,
                                        new AppDomainSetup { ApplicationBase = applicationBase },
                                        ps);

            Console.WriteLine("Loading Third Party DLL");            
            var plugin = (IPlugin)domain.CreateInstanceFromAndUnwrap(thirdPartyAssemblyPath, thirdPartyClassPath);
            
            Console.WriteLine("Attempting To Read A file");
            var canRead = plugin.ReadFile("C:\\Temp\\ReadFile.txt");
            Console.WriteLine(" {0}",canRead);
            Console.WriteLine("Attempting To Write A File");
            var canWrite = plugin.CreateFile("C:\\Temp\\ShouldNeverGetCreated.txt");
            Console.WriteLine(" {0}",canWrite);

            Console.WriteLine("Unloading Domain");
            AppDomain.Unload(domain);
            Console.WriteLine("Domain Unloaded");

            Console.WriteLine("Attempting To Run Method On ThirdParty DLL");
            try
            {
                plugin.ReadFile("filePath");
                Console.WriteLine(" Ran after unload (WILL NEVER HAPPEN");
            }
            catch
            {
                Console.WriteLine(" Failed to run as have been unloaded");
            }
        }
    }
}
