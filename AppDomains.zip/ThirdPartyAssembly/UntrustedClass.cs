﻿using System;
using AppDomains;

namespace ThirdPartyAssembly
{
    public class UntrustedClass : MarshalByRefObject, IPlugin 
    {

        public bool CreateFile(string filePath)
        {
            try
            {
                System.IO.File.Create(filePath);
                return true;
            }
            catch
            {
                return false;
            }
        }


        public bool ReadFile(string filePath)
        {
            try
            {
                System.IO.File.ReadAllText(filePath);
                return true;
            }
            catch
            {
                return false;
            }
        }


    }
}
